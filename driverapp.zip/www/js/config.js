/*Driver App Configuration*/

var krms_driver_config ={	
	'ApiUrl':"http://www.food.arizonaonline.org/driver/api",
	'DialogDefaultTitle':"Food Driver App",	
	'PushProjectID':"872019868979",	
	'APIHasKey':"457845778422112545"
};